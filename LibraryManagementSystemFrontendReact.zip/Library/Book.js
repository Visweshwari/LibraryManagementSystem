import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';

const Dashboard = () => {
    const [stats, setStats] = useState({ books: 0, borrowed: 0, members: 0 });

    useEffect(() => {
        axios.get('/api/stats').then(response => setStats(response.data));
    }, []);

    return (
        <div>
            <h2>Dashboard</h2>
            <p>Total Books: {stats.books}</p>
            <p>Books Borrowed: {stats.borrowed}</p>
            <p>Members: {stats.members}</p>
        </div>
    );
};

const Books = () => {
    const [books, setBooks] = useState([]);

    useEffect(() => {
        axios.get('/api/books').then(response => setBooks(response.data));
    }, []);

    return (
        <div>
            <h2>Books Management</h2>
            {books.map(book => (
                <div key={book.id}>{book.title} by {book.author}</div>
            ))}
        </div>
    );
};

const Members = () => {
    const [members, setMembers] = useState([]);

    useEffect(() => {
        axios.get('/api/members').then(response => setMembers(response.data));
    }, []);

    return (
        <div>
            <h2>Members Management</h2>
            {members.map(member => (
                <div key={member.id}>{member.name} - {member.email}</div>
            ))}
        </div>
    );
};

const Borrowing = () => {
    const [borrowed, setBorrowed] = useState([]);

    useEffect(() => {
        axios.get('/api/borrow').then(response => setBorrowed(response.data));
    }, []);

    return (
        <div>
            <h2>Borrowing System</h2>
            {borrowed.map(record => (
                <div key={record.id}>{record.member.name} borrowed {record.book.title}</div>
            ))}
        </div>
    );
};

export { Dashboard, Books, Members, Borrowing };