package com.library.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class BookEntity 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
		private Long id;
		private String title;
		private String author;
		@Column(unique=true)
		private String isbn;
		private int publicationYear;
		private int quantity;
		private int available;
		
		
		public BookEntity(Long id, String title, String author, String isbn, int publicationYear, int quantity,
				int available) {
			super();
			this.id = id;
			this.title = title;
			this.author = author;
			this.isbn = isbn;
			this.publicationYear = publicationYear;
			this.quantity = quantity;
			this.available = available;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getAuthor() {
			return author;
		}
		public void setAuthor(String author) {
			this.author = author;
		}
		public String getIsbn() {
			return isbn;
		}
		public void setIsbn(String isbn) {
			this.isbn = isbn;
		}
		public int getPublicationYear() {
			return publicationYear;
		}
		public void setPublicationYear(int publicationYear) {
			this.publicationYear = publicationYear;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public int getAvailable() {
			return available;
		}
		public void setAvailable(int available) {
			this.available = available;
		}
		@Override
		public String toString() {
			return "BookEntity [id=" + id + ", title=" + title + ", author=" + author + ", isbn=" + isbn
					+ ", publicationYear=" + publicationYear + ", quantity=" + quantity + ", available=" + available
					+ "]";
		}
		 
		 
		


}
