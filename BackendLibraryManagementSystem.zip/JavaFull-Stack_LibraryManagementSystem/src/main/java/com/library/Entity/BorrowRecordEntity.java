package com.library.Entity;

import java.sql.Date;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class BorrowRecordEntity 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
		 private Long id;
		 private int bookId;
		 private int memberId; 
		 private LocalDate borrowDate;
		 private LocalDate dueDate;
		 @Column(nullable=false)
		 private LocalDate returnDate;
		 private String status;
		 
		 
		public BorrowRecordEntity(Long id, int bookId, int memberId, LocalDate borrowDate, LocalDate dueDate,
				LocalDate returnDate, String status) {
			super();
			this.id = id;
			this.bookId = bookId;
			this.memberId = memberId;
			this.borrowDate = borrowDate;
			this.dueDate = dueDate;
			this.returnDate = returnDate;
			this.status = status;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public int getBookId() {
			return bookId;
		}
		public void setBookId(int bookId) {
			this.bookId = bookId;
		}
		public int getMemberId() {
			return memberId;
		}
		public void setMemberId(int memberId) {
			this.memberId = memberId;
		}
		public LocalDate getBorrowDate() {
			return borrowDate;
		}
		public void setBorrowDate(LocalDate borrowDate) {
			this.borrowDate = borrowDate;
		}
		public LocalDate getDueDate() {
			return dueDate;
		}
		public void setDueDate(LocalDate dueDate) {
			this.dueDate = dueDate;
		}
		public LocalDate getReturnDate() {
			return returnDate;
		}
		public void setReturnDate(LocalDate returnDate) {
			this.returnDate = returnDate;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		@Override
		public String toString() {
			return "BorrowRecordEntity [id=" + id + ", bookId=" + bookId + ", memberId=" + memberId + ", borrowDate="
					+ borrowDate + ", dueDate=" + dueDate + ", returnDate=" + returnDate + ", status=" + status + "]";
		}
		 
		 

}
