package com.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaFullStackLibraryManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaFullStackLibraryManagementSystemApplication.class, args);
	}

}
