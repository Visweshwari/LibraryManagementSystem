package com.library.Controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class MemberController {

}
