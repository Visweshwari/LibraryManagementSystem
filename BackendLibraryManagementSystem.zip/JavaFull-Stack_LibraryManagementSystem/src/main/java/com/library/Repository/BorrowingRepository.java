package com.library.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.Entity.BookEntity;
import com.library.Entity.BorrowRecordEntity;

public interface BorrowingRepository extends JpaRepository<BorrowRecordEntity, Long>
{

}
