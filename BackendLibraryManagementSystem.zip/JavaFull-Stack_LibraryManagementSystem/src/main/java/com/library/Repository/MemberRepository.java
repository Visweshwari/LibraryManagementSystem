package com.library.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.Entity.MemberEntity;

public interface MemberRepository extends JpaRepository<MemberEntity, Long>
{

}
